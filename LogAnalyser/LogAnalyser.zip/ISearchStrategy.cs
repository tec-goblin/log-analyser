﻿using System.Collections.Generic;

namespace LogAnalyser
{
    public interface ISearchStrategy
    {
        LogMatch? Apply(object parsedLine);
        IEnumerable<LogMatch> NotifyLastLine();
    }
}