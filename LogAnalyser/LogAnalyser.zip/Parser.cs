﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LogAnalyser
{
    public class Parser
    {
        private readonly Action<LogMatch> print;

        public Parser(Action<LogMatch> print)
        {
            this.print = print;
        }

        public void ParseLogs(string folder, ISearchStrategy searchStrategy /*we can easily implement chaining searchStrategies if needed*/)
        {
            var folders = SearchForSubFolders(); //if one, operate in main folder
            var aggregates = from f in folders.AsParallel()
                             select ParseFolder(searchStrategy, f);

            foreach(var agr in aggregates[1..]) //to test with count of 1, bug with the compiler
                aggregates[0].Merge(agr);

            print(aggregates[0].ToString());
        }

        private Aggregate ParseFolder(ISearchStrategy searchStrategy, object folder)
        {
            var folderAggregate = new Aggregate();

            foreach (var file in folder)
            {
                foreach (var line in file)
                {
                    var parsedLine = Parse(line);
                    var result = searchStrategy.Apply(parsedLine);
                    if (result.HasValue)
                    {
                        print(result); //bug here, it should realise it's not nullable
                        folderAggregate.Update(result);
                    }
                }
            }
            var results = searchStrategy.NotifyLastLine();
            foreach (var result in results)
            {
                print(result);
                folderAggregate.Update(result);
            }

            return folderAggregate;
        }

        private object Parse(string line) => throw new NotImplementedException();
    }
}
