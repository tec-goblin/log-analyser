﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LogAnalyser
{
    public class SuccessAnalysis : ISearchStrategy
    {
        public SuccessAnalysis(string entryUrl, string successPattern, short? successTimeOut = 1200)
        {
            EntryUrl = entryUrl;
            SuccessPattern = successPattern;
            SuccessTimeOut = successTimeOut;
        }

        public string EntryUrl { get; }
        public string SuccessPattern { get; }
        public short? SuccessTimeOut { get; }

        public LogMatch? Apply(object parsedLine) => throw new NotImplementedException();
        public IEnumerable<LogMatch> NotifyLastLine() => throw new NotImplementedException();
    }
}
