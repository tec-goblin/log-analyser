﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LogAnalyser
{
    class SimpleSearch : ISearchStrategy
    {
        public SimpleSearch(string? pattern, int? perId)
        {
            if (pattern == null && !perId.HasValue)
                throw new ArgumentNullException("pattern", "Pattern must have a value if perId doesn't");
            Pattern = pattern;
            PerId = perId;
        }

        public string? Pattern { get; }
        public int? PerId { get; }

        public LogMatch? Apply(object parsedLine) => throw new NotImplementedException();
        public IEnumerable<LogMatch> NotifyLastLine() { yield break; }
    }
}
